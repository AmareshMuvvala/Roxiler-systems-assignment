# Assignment

*Views in Assignments*
1. Success View
<img src="https://res.cloudinary.com/dniq4wbom/image/upload/v1701533472/Screenshot_2023-12-02_212358_jpl6du.png" height="200" width="">
<img src="https://res.cloudinary.com/dniq4wbom/image/upload/v1701534663/Screenshot_2023-12-02_212417_gvfbsp.png" height="100" width="">
<img src="https://res.cloudinary.com/dniq4wbom/image/upload/v1701534673/Screenshot_2023-12-02_212427_gioh7a.png" height="200" width="">

2. Loading View 
<img src="https://res.cloudinary.com/dniq4wbom/image/upload/v1701534689/Screenshot_2023-12-02_212550_vnvx7j.png" height="200" width="">

3. Failure View 
<img src="https://res.cloudinary.com/dniq4wbom/image/upload/v1701534682/Screenshot_2023-12-02_212450_peqles.png" height="200" width="">